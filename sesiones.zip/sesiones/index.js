const http    = require('http');
const express = require('express');
const path    = require('path');
const fs      = require('fs');
const app     = express();

app.set('view engine', 'ejs');
app.set('views', 'views');

const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname, 'public')));

const cookieParser = require("cookie-parser");
app.use(cookieParser());

const session = require("express-session");
app.use(session({
    secret: "mi string secreto que debe ser un string aleatorio muy largo, no como éste",
    resave: false, //La sesión no se guardará en cada petición, sino sólo se guardará si algo cambió
    saveUninitialized: false, //Asegura que no se guarde una sesión para cada petición que no lo necesita
}));

app.get('/', (request, response, next) => {
    response.setHeader('Content-Type', 'text/plain');
    response.setHeader('Set-Cookie','mi_cookie=123 HttpOnly');
    response.send("Hola Mundo");
    response.end(); 
});

app.get('/test_cookie', (req,res)=>{
    res.setHeader('Content-Type', 'text/plain');
    res.send(req.cookies.mi_cookie);
    res.end();
});

app.get('/test_session', (req,res)=>{
    req.session.mi_variable = "valor";
    res.setHeader('Content-Type', 'text/plain');
    res.send(req.session.mi_variable);
    res.end();
});

app.get('/test_session_variable', (req,res)=>{
    res.setHeader('Content-Type', 'text/plain');
    res.send(req.session.mi_variable);
    res.end();
});

app.get('/logout', (req,res)=>{
    req.session.destroy(() => {
        res.redirect("/"); //Este código se ejecuta hasta que la sesión se elimina.
    });
});

const server = http.createServer( (request, response) => {    
    console.log(request.url);
});
app.listen(3000);