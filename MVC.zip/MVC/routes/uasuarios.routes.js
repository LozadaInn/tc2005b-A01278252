const express = require("express");
const path = require("path"); //Vienen con NodeJS no necesitan agregarse
const fs = require("fs"); //Vienen con NodeJS no necesitan agregarse
const router = express.Router();
const controller = require("../controllers/usurios.controllers");

router.get("/obtener_usuarios", controller.index);

module.exports = router;